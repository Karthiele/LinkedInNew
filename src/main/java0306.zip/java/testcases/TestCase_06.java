//package wrapper;

package testcases;


import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import wrapper.LinkedInWrappers;

public class TestCase_06 extends LinkedInWrappers {

	@Test
	public void linkIn() throws InterruptedException {
		String mailReceipt;
		String getMailReceipt;
		
		
		mailReceipt = "Karthikeyan S";
		invokeApp("Chrome", "https://www.linkedin.com/");
		enterById("login-email", "karthielex@gmail.com");
		enterById("login-password", "sjb@1986");
		clickByName("submit");
		Thread.sleep(5000);

		
		
		clickByXPath("//*[@id='account-nav']/ul/li[1]/a");
		
		Thread.sleep(5000);

		clickById("compose-button");
		
		
		enterById("pillbox-input", mailReceipt);
		Thread.sleep(5000);
		
		sendEndterKeyByID("pillbox-input");
		
		enterById("compose-message", "Karthi");
		
		clickById("enter-to-send-checkbox");
		
		clickByClassName("message-submit");
		
		Thread.sleep(5000);
		
		getMailReceipt = getTextByXPath("//*[@id='thread-list']/li[1]/div[1]/a/div[2]/div/h4");
		System.out.println(mailReceipt.toLowerCase());
		
		System.out.println(getMailReceipt.toLowerCase());
		
		
		if(mailReceipt.toLowerCase().equalsIgnoreCase(getMailReceipt.toLowerCase()))
		{
			System.out.println("Mail Sent");
		}
	}
}

