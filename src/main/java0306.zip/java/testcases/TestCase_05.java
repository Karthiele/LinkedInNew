//package wrapper;

package testcases;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import wrapper.LinkedInWrappers;
import wrapper.LinkedInWrappersKarthi;

public class TestCase_05 extends LinkedInWrappersKarthi {

	@Test
	public void linkIn() throws InterruptedException {

		String getComapanyname;

		// Launch Chrome
		invokeApp("Chrome", "https://www.linkedin.com/");

		// Login Linkedin
		loginLinkedInKarthi("karthielex@gmail.com", "sjb@1986");
		Thread.sleep(5000);

		// Click the Advaned Link
		clickByLinkText("Advanced");
		Thread.sleep(3000);

		enterById("advs-company", "Capgeminin");

		getComapanyname = getAttributeValueByID("advs-company", "value");
		System.out.println("Company Name is :" + getComapanyname);

		clickById("adv-F-N-ffs");// ("//*[@id='adv-F-N-ffs']");
		clickByXPath("//*[@id='adv-facet-G']/fieldset/legend");
		clickByClassName("add-facet-button");
		Thread.sleep(3000);
		enterByName("f_G", "I");
		Thread.sleep(3000);
		sendEndterKeyByName("f_G");

		clickByXPath("//*[@id='peopleSearchForm']/div[1]/input[2]");
		getComapanyname = getAttributeValueByID("advs-company", "value");

		if (getComapanyname.isEmpty()) {
			System.out.println("Company Name is cleared");
		}

		if (!isSelectedByXpath("//*[@id='adv-in:0-G-ffs']")) {
			System.out.println("Country is cleared");
		}

		Thread.sleep(1000);
		clickById("adv-F-N-ffs");
		clickByName("submit");

		closeCurrentWindow();
	}

}
