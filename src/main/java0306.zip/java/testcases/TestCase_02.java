
//package wrapper;

package testcases;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import wrapper.LinkedInWrappers;

public class TestCase_02 extends LinkedInWrappers {

	@Test
	public void linkIn() throws InterruptedException {

		String result;
		String result2 = "";

		// Launch Chrome
		invokeApp("Chrome", "https://www.linkedin.com/");

		// Login Linkedin
		loginLinkedIn("karthielex@gmail.com", "sjb@1986");
		Thread.sleep(5000);

		// Click the Advaned Link
		clickByLinkText("Advanced");
		Thread.sleep(5000);

		// Close the Frame
		clickByXPath("//*[@id='advs']/div[1]/button");
		Thread.sleep(5000);

		// Get the Total Result Count
		result = getTextByXPath("//*[@id='results_count']/div/p/strong");
		Thread.sleep(5000);
		System.out.println("Total Count before Split :" + result); // Print The
																	// Result
																	// count
																	// before
																	// the Split
		result = Split(result, ','); // Split method used to remove the , from
										// the result.
		System.out.println("Total Count after Split :" + result); // Print The
																	// Result
																	// count
																	// after the
																	// Split
		Thread.sleep(5000);

		// Close the 2nd Connection
		clickByXPath("//*[@id='pivot-bar']/ul/li[2]/button");
		Thread.sleep(5000);

		// Get the Result Count after closing the 2nd connection
		result = getTextByXPath("//*[@id='results_count']/div/p/strong");
		System.out.println("2nd Connection closed. Total Count before Split :" + result); // Print
																							// The
																							// Result
																							// count
																							// before
																							// the
																							// Split
		result = Split(result, ',');
		System.out.println("2nd Connection closed. Total Count after Split :" + result); // Print
																							// The
																							// Result
																							// count
																							// before
																							// the
																							// Split
		Thread.sleep(5000);

		// Close the Group Connection
		clickByXPath("//*[@id='pivot-bar']/ul/li[2]/button");
		Thread.sleep(5000);

		// Get the Result Count after closing the Group Members/
		result = getTextByXPath("//*[@id='results_count']/div/p/strong");
		System.out.println("Group Members closed. Total Count before Split :" + result); // Print  																						// The
																							// Result
																							// count
																							// before
																							// the
																							// Split
		result = Split(result, ',');
		System.out.println("Group Members closed. Total Count before Split :" + result); // Print
																							// The
																							// Result
																							// count
																							// before
																							// the
																							// Split
		Thread.sleep(5000);

		// Get the 1st Connection count from the left side pan
		result2 = getTextByXPath("//*[@id='facet-N']/fieldset/div/ol/li[2]/div/span");
		Thread.sleep(5000);
		System.out.println("1st Connection count before Split :" + result2);
		result2 = Split(result2, '(');
		result2 = Split(result2, ')');
		System.out.println("1st Connection count After Split :" + result2);

		// Compare the Results
		if (result.equalsIgnoreCase(result2))

		{
			System.out.println("1st Connection count is matching with the result count");
		} 
		else 
		{
			System.out.println("1st Connection count is not matching with the result count");
		}
		closeCurrentWindow();
	}

}
