//package wrapper;

package testcases;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import wrapper.LinkedInWrappers;
import wrapper.WrapperMethods;

public class TestCase_03 extends LinkedInWrappers

{
	@Test
	public void TestCase() throws InterruptedException {

		String browser = "Firefox";
		int count;
		boolean skillExist = false;

		invokeApp(browser, "https://www.linkedin.com/");
		enterById("login-email", "karthielex@gmail.com");
		enterById("login-password", "sjb@1986");
		clickByName("submit");

		clickByLinkText("Profile");
		verifyTextByXPath("//*[@id='overview-summary-current']/td/span/ol/li/span", "Patni Computer Systems");

		List<WebElement> allSkillS = findAllElementsByClassName("endorse-item-name-text");

		count = allSkillS.size();

		skillExist = isSkillExist(allSkillS);

		if (!skillExist) {
			addSkillExist(count,browser);
		}

		Thread.sleep(5000); // Sleep to slowdown

		skillExist = false;

		allSkillS = findAllElementsByClassName("endorse-item-name-text");

		skillExist = isSkillExist(allSkillS);

		if (skillExist) {
			System.out.println("Added Skill is avaialble.");
		} else {
			System.out.println("Added Skill is not avaialble.");
		}

		closeCurrentWindow();
	}

	public void addSkillExist(int count, String browser) throws InterruptedException {
		String tab = "\t";
		clickByXPath("//*[@id='background-skills']/button");
		enterById("edit-skills-add-ta", "Selenium");

		clickById("edit-skills-add-btn");
		Thread.sleep(5000);
		clickById("edit-skills-add-ta");

		if (browser.equalsIgnoreCase("Firefox"))

		{

			for (int i = 0; i <= count + 1; i++) {
				tab = tab + "\t";
			}
			Thread.sleep(5000);
			enterById("edit-skills-add-ta", tab);
		}

		clickByXPath("//*[@id='skills-editor-form']/p/input");
		Thread.sleep(5000);
	}

	public boolean isSkillExist(List<WebElement> allSkillS) {
		boolean skillflag = false;
		for (WebElement skill : allSkillS) {
			System.out.println("get skill" + skill.getText());
			if (skill.getText().equalsIgnoreCase("Selenium")) {
				skillflag = true;
				break;
			}
		}
		return skillflag;
	}
}
