//package wrapper;

package testcases;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import wrapper.LinkedInWrappers;

public class TestCase_04 extends LinkedInWrappers {

	@Test
	public void linkIn() throws InterruptedException {

		String viewcolor;
		invokeApp("Chrome", "https://www.linkedin.com/");
		enterById("login-email", "karthielex@gmail.com");
		enterById("login-password", "sjb@1986");
		clickByName("submit");
		Thread.sleep(5000);
		clickByLinkText("Jobs");
		enterById("job-search-box", "Selenium\t");
		clickByClassName("search-button");

		viewcolor = getCSSvaluebyCSS("#results > li.mod.result.idx0.job > div > div.srp-actions.blue-button > a",
				"background-color");

		System.out.println(viewcolor);

		if (viewcolor.contains("rgba(40, 123, 188, 1)")) {
			System.out.println("Background of the First View button is blue: " + viewcolor);
		} else {
			System.out.println("Background of the First View button is not blue: " + viewcolor);
		}

		clickViewButton(2);
		
		Thread.sleep(5000);
		
		System.out.println("Name of the Company is : " + getTextByClassName("company"));

		clickByLinkText(getTextByClassName("company"));
		
		System.out.println("Number of employees count : " + getTextByClassName("company-size"));
	}

	public void clickViewButton(int reqLink)

	{
		List<WebElement> links = findAllElementsByLink("View");

		links.get(reqLink - 1).click();

	}
}
