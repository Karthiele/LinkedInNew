//package wrapper;

package testcases;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import wrapper.LinkedInWrappers;
import wrapper.LinkedInWrappersKarthi;

public class TestCase_07 extends LinkedInWrappersKarthi {

	@Test
	public void linkIn() throws InterruptedException {

		String color;
		int countConnect;

		// Launch Chrome
		invokeApp("Chrome", "https://www.linkedin.com/");

		// Login Linkedin
		loginLinkedInKarthi("karthielex@gmail.com", "sjb@1986");
		Thread.sleep(5000);

		clickById("dropdowntest");
		Thread.sleep(3000);

		countConnect = countAllElementsByClassName("screen-reader-text");

		System.out.println("Total Connect Links : " + countConnect);

		clickConnect(2);

	}


}
