package wrapper;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;

public class LinkedInWrappersKarthi extends WrapperMethods{
	
	public boolean loginLinkedInKarthi(String userName, String passWord){
		
		try {
				
			enterById("login-email",userName);
			enterById("login-password",passWord);
			clickByName("submit");
			return true;
		} 
		catch (NoSuchElementException e) 
		{
			System.out.println("Unable to login");
			e.printStackTrace();
			return false;
		}
	}
	
	public String Split(String data, char spliter) {
		String afterSplit = "";
		for (char c : data.toCharArray()) {
			if (c != spliter) {
				afterSplit = afterSplit + c;
			}
			
		}		
		return afterSplit;
	}
	public void clickConnect(int linkToClick) throws InterruptedException {
		List<WebElement> currencies = driver.findElements(By.tagName("button"));

		int connectCount = 0;
		String name = null;
		String name2 = null;
		String color;

		for (WebElement option : currencies) {

			System.out.println("Text :" + option.getAttribute("title"));

			if (option.getText().contains("Connect with ")) {
				connectCount = connectCount + 1;
				if (connectCount == linkToClick) {
					name = option.getAttribute("title").replace("Connect with ", "");
					System.out.println("Name :" + name);
					color = option.getCssValue("background").toString();
					System.out.println("Colour 1:" + color);
					color = color.replace(" replacement)none repeat scroll 0% 0% / auto padding-box border-box", "");
					System.out.println("Colour 2:" + color);

					if (color.equalsIgnoreCase(
							"rgb(0, 119, 181) none repeat scroll 0% 0% / auto padding-box border-box")) {
						System.out.println("Connection button color is Blue");

					}
					option.click();
					Thread.sleep(5000);
					name2 = getTextByCSS("#global-alert-queue > div");
					break;
				}
			}

		}

		System.out.println("Name:" + name);

		System.out.println("Name2:" + name2);

		if (name2.contains("Invitation sent to " + name)) {
			System.out.println("Invitation Sent Sucessfully");
		} else {
			System.out.println("Invitation not Sent");
		}

		Thread.sleep(5000);
		name2 = getTextByCSS("#global-alert-queue > div");

		if (name2.equalsIgnoreCase("Invitation sent to " + name)) {
			System.out.println("Invitation Sent Sucessfully message still displaying");
		} else {
			System.out.println("Invitation Sent message not displaying");
		}

	}

}
